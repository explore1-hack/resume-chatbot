from langchain_community.vectorstores import FAISS
from langchain.chains import RetrievalQA
from langchain.chat_models import ChatOpenAI
from langchain_community.embeddings import HuggingFaceEmbeddings
from dotenv import load_dotenv
import os

# Load Together API key
load_dotenv()
api_key = os.getenv("TOGETHER_API_KEY")

# Load vector store + embeddings
db = FAISS.load_local(
    "faiss_resume_index",
    HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2"),
    allow_dangerous_deserialization=True
)

# Use Together.ai LLM
llm = ChatOpenAI(
    model_name="mistralai/Mixtral-8x7B-Instruct-v0.1",
    openai_api_key=api_key,
    openai_api_base="https://api.together.xyz/v1"
)

# Create RetrievalQA chain
qa = RetrievalQA.from_chain_type(llm=llm, retriever=db.as_retriever())

# Simple CLI
print("🤖 Ask anything about your resume (type 'exit' to quit):")

while True:
    query = input("You: ")
    if query.lower() in ["exit", "quit"]:
        print("👋 Goodbye!")
        break
    print("Bot:", qa.run(query))
