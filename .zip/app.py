import streamlit as st
from langchain_community.vectorstores import FAISS
from langchain.chains import RetrievalQA
from langchain.chat_models import ChatOpenAI
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.document_loaders import TextLoader, PyPDFLoader
from langchain.text_splitter import CharacterTextSplitter
from dotenv import load_dotenv
import os
import tempfile

load_dotenv()
api_key = os.getenv("TOGETHER_API_KEY")

st.set_page_config(page_title="🧠 Resume Chatbot", layout="centered")
st.title("📤 Upload Resume & Ask 🤖")

uploaded_file = st.file_uploader("Upload your `.txt` or `.pdf` resume:", type=["txt", "pdf"])

if uploaded_file:
    with tempfile.NamedTemporaryFile(delete=False) as tmp_file:
        tmp_file.write(uploaded_file.read())
        tmp_path = tmp_file.name

    # Load and split
    if uploaded_file.name.endswith(".txt"):
        loader = TextLoader(tmp_path)
    else:
        loader = PyPDFLoader(tmp_path)

    documents = loader.load()
    splitter = CharacterTextSplitter(chunk_size=500, chunk_overlap=50)
    docs = splitter.split_documents(documents)

    # Embed using HuggingFace
    embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
    db = FAISS.from_documents(docs, embeddings)

    # LLM from Together.ai
    llm = ChatOpenAI(
        model_name="mistralai/Mixtral-8x7B-Instruct-v0.1",
        openai_api_key=api_key,
        openai_api_base="https://api.together.xyz/v1"
    )

    qa_chain = RetrievalQA.from_chain_type(llm=llm, retriever=db.as_retriever())

    st.success("✅ Resume uploaded and processed. You can ask now!")

    query = st.text_input("Ask anything about your resume 👇")

    if query:
        with st.spinner("Thinking..."):
            response = qa_chain.run(query)
            st.success(response)
else:
    st.info("Please upload a `.txt` or `.pdf` file to get started.")